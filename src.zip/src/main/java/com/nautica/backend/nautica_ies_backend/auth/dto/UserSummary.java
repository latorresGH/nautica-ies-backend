// src/main/java/com/nautica/backend/nautica_ies_backend/auth/dto/UserSummary.java
package com.nautica.backend.nautica_ies_backend.auth.dto;

public record UserSummary(String nombre, String apellido, String correo, String rol) {}
