package com.nautica.backend.nautica_ies_backend.models.enums;

public enum FormaPago {
    efectivo, 
    transferencia,
    tarjeta,
    debito_automatico
}