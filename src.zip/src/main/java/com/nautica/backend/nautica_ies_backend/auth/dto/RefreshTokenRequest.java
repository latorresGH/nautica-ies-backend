// RefreshTokenRequest.java
package com.nautica.backend.nautica_ies_backend.auth.dto;

public record RefreshTokenRequest(String refreshToken) {
}
