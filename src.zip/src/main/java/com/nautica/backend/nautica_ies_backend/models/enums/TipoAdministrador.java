package com.nautica.backend.nautica_ies_backend.models.enums;

public enum TipoAdministrador {
    gerente,
    jefe,
    admin_usuarios
}
