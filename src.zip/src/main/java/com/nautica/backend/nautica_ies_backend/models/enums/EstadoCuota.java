package com.nautica.backend.nautica_ies_backend.models.enums;

public enum EstadoCuota { 
    pendiente, 
    pagada, 
    vencida 
}
