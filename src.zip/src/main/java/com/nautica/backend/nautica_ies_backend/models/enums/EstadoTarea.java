package com.nautica.backend.nautica_ies_backend.models.enums;

public enum EstadoTarea {
    realizado, 
    pendiente, 
    cancelado
}
