package com.nautica.backend.nautica_ies_backend.controllers.dto;

public record EmbarcacionResumenDTO(
    Long id,
    String nombre,
    String matricula
) {}
