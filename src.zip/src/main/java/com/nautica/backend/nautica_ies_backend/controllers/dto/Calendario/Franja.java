package com.nautica.backend.nautica_ies_backend.controllers.dto.Calendario;

import java.time.LocalTime;

public record Franja(LocalTime desde, LocalTime hasta) {}
