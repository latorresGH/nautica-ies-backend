// src/main/java/com/nautica/backend/nautica_ies_backend/auth/dto/LoginRequest.java
package com.nautica.backend.nautica_ies_backend.auth.dto;

public record LoginRequest(String correo, String contrasena) {}
